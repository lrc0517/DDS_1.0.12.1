(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define("DuiCustom", [], factory);
	else if(typeof exports === 'object')
		exports["DuiCustom"] = factory();
	else
		root["DuiCustom"] = factory();
})(this, function() {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/lib/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 2);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(4)
}
var Component = __webpack_require__(5)(
  /* script */
  __webpack_require__(1),
  /* template */
  __webpack_require__(6),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-6d7cb46e",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__assets_fonts_iconfont_css__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__assets_fonts_iconfont_css___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__assets_fonts_iconfont_css__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'music',

  data: function data() {
    return {
      currentMusic: '',
      currentIndex: 0,
      playing: false && this.isAudioFile(this.currentMusic.src),
      now: 0,
      nativeAudio: {},
      totalTime: '',
      srcError: false,
      shouldRotate: false,
      rotateInterval: '',
      innerAutoplay: this.autoplay
    };
  },
  mounted: function mounted() {
    var _self = window.currentMusic = this;
    this.goto(0, this.innerAutoplay);

    // 音乐控制指令订阅
    if (window.Dui) {
      // 指令集合
      window.Dui.subscribe('command://mediacontrol', function (data) {
        window.focusPause = false;
        switch (data.data && data.data.action) {
          case '暂停':
            window.focusPause = true;
            window.pauseAllAudio();
            break;
          case '暂停播放':
            window.focusPause = true;
            window.pauseAllAudio();
            break;
          case '继续':
            window.continuePlay();
            break;
          case '继续播放':
            window.continuePlay();
            break;
          case '下一首':
            _self === window.currentMusic && window.currentMusic.next();
            break;
          case '下一个':
            _self === window.currentMusic && window.currentMusic.next();
            break;
          case '上一首':
            _self === window.currentMusic && window.currentMusic.prev();
            break;
          case '上一个':
            _self === window.currentMusic && window.currentMusic.prev();
            break;
          case '重新播放':
            _self === window.currentMusic && window.currentMusic.replay();
            break;
          case '切换':
            _self === window.currentMusic && window.currentMusic.gotoAnother();
            break;
          case '换一个':
            _self === window.currentMusic && window.currentMusic.gotoAnother();
            break;
        }
      });
      // 暂停
      window.Dui.subscribe('command://mediacontrol.pause', function (data) {
        window.focusPause = true;
        window.pauseAllAudio();
      });
      // 继续播放
      window.Dui.subscribe('command://mediacontrol.continue', function (data) {
        window.focusPause = false;
        window.continuePlay();
      });
      // 下一首
      window.Dui.subscribe('command://mediacontrol.next', function (data) {
        window.focusPause = false;
        _self === window.currentMusic && window.currentMusic.next();
      });
      // 上一首
      window.Dui.subscribe('command://mediacontrol.prev', function (data) {
        window.focusPause = false;
        _self === window.currentMusic && window.currentMusic.prev();
      });
      // 重新播放
      window.Dui.subscribe('command://mediacontrol.replay', function (data) {
        window.focusPause = false;
        _self === window.currentMusic && window.currentMusic.replay();
      });
      // 随便换一首
      window.Dui.subscribe('command://mediacontrol.another', function (data) {
        window.focusPause = false;
        _self === window.currentMusic && window.currentMusic.gotoAnother();
      });
    }
    // window.replay = this.replay
    // window.gotoAnother = this.gotoAnother
  },


  props: {
    message: Object,
    img: String,
    title: String,
    subtitle: String,
    src: String,
    srcType: String,
    autoplay: {
      default: true
    }
  },

  methods: {
    togglePlay: function togglePlay() {
      if (!this.isAudioFile(this.src)) return;
      if (this.$refs.audio.paused) {
        this.pauseAllAudio();
        this.play();
      } else {
        this.pause();
      }
    },
    changeTime: function changeTime(event) {
      if ('ontouchend' in document) return;
      var progressBar = this.$refs.progressBar;
      var coordStart = progressBar.getBoundingClientRect().left;
      var coordEnd = event.pageX || -event.offsetX;
      this.nativeAudio.currentTime = (coordEnd - coordStart) / progressBar.offsetWidth * this.nativeAudio.duration;
      this.now = this.nativeAudio.currentTime;
      if (!this.nativeAudio.paused) {
        this.play();
      }
    },
    touchMove: function touchMove(event) {
      var progressBar = this.$refs.progressBar;
      var coordStart = progressBar.getBoundingClientRect().left;
      var coordEnd = event.touches[0].pageX;
      this.$refs.now.style.width = ((coordEnd - coordStart) / progressBar.offsetWidth).toFixed(3) * 100 + '%';
    },
    touchEnd: function touchEnd(event) {
      this.nativeAudio.currentTime = this.$refs.now.style.width.replace('%', '') / 100 * this.nativeAudio.duration;
      this.now = this.nativeAudio.currentTime;
      if (!this.nativeAudio.paused) {
        this.play();
      }
    },
    transformTime: function transformTime(seconds) {
      if (seconds && !isNaN(seconds)) {
        var m = void 0,
            s = void 0;
        m = Math.floor(seconds / 60);
        m = m.toString().length === 1 ? '0' + m : m;
        s = Math.floor(seconds - 60 * m);
        s = s.toString().length === 1 ? '0' + s : s;
        return m + ':' + s;
      }
    },
    isAudioFile: function isAudioFile(link) {
      return !this.srcError;
    },
    playedTime: function playedTime() {
      if (this.now && this.transformTime(this.now)) {
        return this.transformTime(this.now);
      } else {
        return '00:00';
      }
    },
    handleError: function handleError(event) {
      this.srcError = true;
    },
    play: function play() {
      if (this.nativeAudio) {
        window.currentMusic = this;
        this.nativeAudio.play();
        if (this.nativeAudio.paused) {
          this.playing = false;
        } else {
          this.playing = true;

          var _self = this;
          if (!this.rotateInterval) {
            this.rotateInterval = setInterval(function () {
              _self.shouldRotate = !_self.shouldRotate;
            }, 300);
          }
        }
      }
    },
    pause: function pause() {
      if (this.nativeAudio) {
        this.nativeAudio.pause();
        if (this.nativeAudio.paused) {
          this.playing = false;

          clearInterval(this.rotateInterval);
          this.rotateInterval = '';
        } else {
          this.playing = true;
        }
      }
    },
    handleLoad: function handleLoad() {
      this.srcError = false;
      if (this.innerAutoplay && !this.srcError && this.nativeAudio && this.nativeAudio.currentTime === 0) {
        this.nativeAudio.currentTime = 0;
        this.play();
      }
    },
    pauseAllAudio: function pauseAllAudio() {
      // 暂停所有Audio
      var audioList = document.getElementsByTagName('audio');
      for (var i = 0; i < audioList.length; i++) {
        audioList[i].pause();
      }
    },
    goto: function goto(index) {
      var _this = this;

      var autoplay = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

      this.pauseAllAudio();
      if (!this.message.data || !this.message.data.content || !this.message.data.content[index]) return;

      this.currentMusic = this.message.data.content[index];
      this.currentIndex = index;

      this.nativeAudio = this.$refs.audio;

      this.nativeAudio.addEventListener('play', function () {
        _this.totalTime = _this.transformTime(_this.nativeAudio.duration);
        _this.now = _this.nativeAudio.currentTime;
        _this.interval = setInterval(function () {
          if (isNaN(_this.totalTime)) {
            _this.totalTime = _this.transformTime(_this.nativeAudio.duration);
          }

          _this.now = _this.nativeAudio.currentTime;
          if (_this.nativeAudio.ended) {
            clearInterval(_this.interval);
            _this.playing = false;

            clearInterval(_this.rotateInterval);
            _this.rotateInterval = '';

            if (_this.message.data.content.length - 1 !== _this.currentIndex && _this.currentIndex !== 3) {
              _this.next();
            }
          } else if (_this.nativeAudio.paused) {
            _this.pause();
          } else if (!_this.nativeAudio.paused) {
            _this.play();
          }
          if (window.focusPause) {
            window.pauseAllAudio();
          }
        }, 1000);
        _this.now = _this.nativeAudio.currentTime;
      });

      if (autoplay) {
        this.replay();
      }
    },
    prev: function prev() {
      if (!this.message.data || !this.message.data.content) return;
      var length = this.message.data.content.length > 4 ? 4 : this.message.data.content.length;
      this.currentIndex = this.currentIndex - 1 < 0 ? length - 1 : this.currentIndex - 1;
      this.goto(this.currentIndex);
    },
    next: function next() {
      if (!this.message.data || !this.message.data.content) return;
      var length = this.message.data.content.length > 4 ? 4 : this.message.data.content.length;
      this.currentIndex = this.currentIndex + 1 >= length ? 0 : this.currentIndex + 1;
      this.goto(this.currentIndex);
    },
    replay: function replay() {
      this.pauseAllAudio();
      this.nativeAudio.currentTime = 0;
      this.nativeAudio.load();
      this.innerAutoplay = true;
      this.play();
    },

    // 随便换一首歌
    gotoAnother: function gotoAnother() {
      if (!this.message.data || !this.message.data.content) return;
      var length = this.message.data.content.length > 4 ? 4 : this.message.data.content.length;
      // 只有一首歌的话就重新播放这一首
      if (length === 1) {
        this.replay();
      } else if (length > 1) {
        // 随机一个index，比如一共5首歌，去掉当前播放的，剩下4首，随机一个0-3中间的数字，如果随机到的数字比当前播放的索引大或者相等，加1就是想要的
        var radomIndex = parseInt(Math.random() * length - 1);
        if (radomIndex >= this.currentIndex) radomIndex += 1;
        this.goto(radomIndex);
      }
    }
  },

  computed: {}
});

/***/ }),
/* 2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__src_music__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__src_music___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__src_music__);
// import HelloWorld from './src/hello-world'
// import CustomCard from './src/custom-card'
// import gaodeList from './src/gaodeList'
// import gaodeFoodList from './src/gaodeFoodList'
// import foodList from './src/foodList'
// import hotelList from './src/hotelList'
// import placeList from './src/placeList'

// import weather from './src/weather'

// 导出 install 函数
// Vue.use() 会调用这个函数
var install = function install(Vue) {
  var opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  // 如果安装过就忽略
  if (install.installed) return;

  // 指定组件 name
  // Vue.component(HelloWorld.name, HelloWorld)
  // Vue.component(CustomCard.name, CustomCard)
  // Vue.component(gaodeList.widgetName, gaodeList)
  // Vue.component('gaodeFoodList', gaodeFoodList)
  // Vue.component('foodList', foodList)
  // Vue.component('hotelList', hotelList)
  // Vue.component('placeList', placeList)
  Vue.component('music', __WEBPACK_IMPORTED_MODULE_0__src_music___default.a);
  // Vue.component('weather', weather)
};

// 自动安装 方便打包成压缩文件, 用<script scr=''></script>的方式引用
if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue);
}

// 把模块导出
/* harmony default export */ __webpack_exports__["default"] = ({
  install: install,
  // helloWorld: HelloWorld,
  // customContentCard: CustomCard
  // gaodeList: gaodeList,
  // gaodeFoodList: gaodeFoodList,
  // gaodeFoodList: foodList,
  // scapeList: placeList,
  // hotelList: hotelList,
  music: __WEBPACK_IMPORTED_MODULE_0__src_music___default.a
  // weather: weather
});

/***/ }),
/* 3 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 4 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 5 */
/***/ (function(module, exports) {

/* globals __VUE_SSR_CONTEXT__ */

// this module is a runtime utility for cleaner component module output and will
// be included in the final webpack user bundle

module.exports = function normalizeComponent (
  rawScriptExports,
  compiledTemplate,
  injectStyles,
  scopeId,
  moduleIdentifier /* server only */
) {
  var esModule
  var scriptExports = rawScriptExports = rawScriptExports || {}

  // ES6 modules interop
  var type = typeof rawScriptExports.default
  if (type === 'object' || type === 'function') {
    esModule = rawScriptExports
    scriptExports = rawScriptExports.default
  }

  // Vue.extend constructor export interop
  var options = typeof scriptExports === 'function'
    ? scriptExports.options
    : scriptExports

  // render functions
  if (compiledTemplate) {
    options.render = compiledTemplate.render
    options.staticRenderFns = compiledTemplate.staticRenderFns
  }

  // scopedId
  if (scopeId) {
    options._scopeId = scopeId
  }

  var hook
  if (moduleIdentifier) { // server build
    hook = function (context) {
      // 2.3 injection
      context =
        context || // cached call
        (this.$vnode && this.$vnode.ssrContext) || // stateful
        (this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) // functional
      // 2.2 with runInNewContext: true
      if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
        context = __VUE_SSR_CONTEXT__
      }
      // inject component styles
      if (injectStyles) {
        injectStyles.call(this, context)
      }
      // register component module identifier for async chunk inferrence
      if (context && context._registeredComponents) {
        context._registeredComponents.add(moduleIdentifier)
      }
    }
    // used by ssr in case component is cached and beforeCreate
    // never gets called
    options._ssrRegister = hook
  } else if (injectStyles) {
    hook = injectStyles
  }

  if (hook) {
    var functional = options.functional
    var existing = functional
      ? options.render
      : options.beforeCreate
    if (!functional) {
      // inject component registration as beforeCreate hook
      options.beforeCreate = existing
        ? [].concat(existing, hook)
        : [hook]
    } else {
      // register for functioal component in vue file
      options.render = function renderWithStyleInjection (h, context) {
        hook.call(context)
        return existing(h, context)
      }
    }
  }

  return {
    esModule: esModule,
    exports: scriptExports,
    options: options
  }
}


/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [(_vm.message.data.content && _vm.message.data.content.length) ? _c('div', {
    staticClass: "music-card"
  }, [_c('div', {
    staticClass: "music-player-container"
  }, [(_vm.currentMusic.imageUrl) ? _c('div', {
    staticClass: "music--img",
    style: ({
      backgroundImage: ("url(" + (_vm.currentMusic.imageUrl) + ")")
    })
  }) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "music--main"
  }, [_c('div', {
    staticClass: "music--title"
  }, [_vm._v(_vm._s(_vm.currentMusic.title))]), _vm._v(" "), _c('div', {
    staticClass: "music--subtitle"
  }, [_vm._v(_vm._s(_vm.currentMusic.subTitle))]), _vm._v(" "), (_vm.currentMusic.linkUrl) ? _c('div', {
    class: {
      'music--ctrl-area': true, 'music--ctrl-area_noimg': !_vm.currentMusic.imageUrl
    }
  }, [_c('div', {
    staticClass: "ctrl-icons"
  }, [_c('i', {
    staticClass: "music--ctrl-ico-shift prev gaode gaode-shangyishou",
    on: {
      "click": _vm.prev
    }
  }), _vm._v(" "), _c('i', {
    staticClass: "music--ctrl-ico-shift next gaode gaode-xiayishou",
    on: {
      "click": _vm.next
    }
  }), _vm._v(" "), _c('i', {
    class: {
      'music--ctrl-ico': true, 'gaode': true, 'gaode-play': !_vm.playing, 'gaode-zanting': _vm.playing
    },
    on: {
      "click": _vm.togglePlay
    }
  })]), _vm._v(" "), _c('div', {
    staticClass: "music-process-container"
  }, [(this.isAudioFile(_vm.currentMusic.linkUrl)) ? _c('div', {
    ref: "progressBar",
    class: {
      'music--process-bar': true, 'music--process-bar_noimg': !_vm.currentMusic.imageUrl
    },
    on: {
      "click": function($event) {
        _vm.changeTime($event)
      },
      "touchstart": function($event) {
        _vm.touchMove($event)
      },
      "touchmove": function($event) {
        _vm.touchMove($event)
      },
      "touchend": function($event) {
        _vm.touchEnd($event)
      }
    }
  }, [_c('div', {
    ref: "now",
    staticClass: "now",
    style: ({
      width: (_vm.now / _vm.nativeAudio.duration).toFixed(3) * 100 + '%'
    })
  })]) : _vm._e(), _vm._v(" "), (this.isAudioFile(_vm.currentMusic.linkUrl)) ? _c('div', {
    class: {
      'music--played-time': true, 'music--played-time_noimg': !_vm.currentMusic.imageUrl
    }
  }, [_vm._v(_vm._s(_vm.playedTime()))]) : _vm._e(), _vm._v(" "), (this.isAudioFile(_vm.currentMusic.linkUrl)) ? _c('div', {
    staticClass: "music--total-time"
  }, [_vm._v(_vm._s(_vm.totalTime))]) : _vm._e()])]) : _vm._e()]), _vm._v(" "), _c('audio', {
    ref: "audio",
    attrs: {
      "src": _vm.currentMusic.linkUrl,
      "autoplay": _vm.innerAutoplay
    },
    on: {
      "error": _vm.handleError,
      "canplay": _vm.handleLoad
    }
  }, [_vm._v("\n        您的浏览器不支持播放音频\n      ")])]), _vm._v(" "), (_vm.message.data.content.length > 1) ? _c('div', {
    staticClass: "music-list"
  }, _vm._l((_vm.message.data.content), function(item, index) {
    return (index < 4) ? _c('div', {
      key: index,
      staticClass: "music-list-item",
      on: {
        "click": function($event) {
          _vm.goto(index)
        }
      }
    }, [(item.imageUrl) ? _c('img', {
      staticClass: "music-list-item-img",
      attrs: {
        "src": item.imageUrl
      }
    }) : _vm._e(), _vm._v(" "), _c('div', {
      staticClass: "music-list-item-btns"
    }, [(index !== _vm.currentIndex) ? _c('i', {
      staticClass: "gaode gaode-play1"
    }) : _vm._e(), _vm._v(" "), (index === _vm.currentIndex) ? _c('i', {
      class: {
        'gaode': true, 'gaode-bofangzhong': true, 'playing': true, 'rotate': _vm.shouldRotate
      }
    }) : _vm._e()]), _vm._v(" "), (item.title) ? _c('div', {
      staticClass: "music--list-item-title"
    }, [_vm._v(_vm._s(item.title))]) : _vm._e(), _vm._v(" "), (item.subTitle || item.label) ? _c('div', {
      staticClass: "music--list-item-label"
    }, [_vm._v(_vm._s(item.subTitle || item.label))]) : _vm._e()]) : _vm._e()
  })) : _vm._e()]) : _vm._e()])
},staticRenderFns: []}

/***/ })
/******/ ]);
});
//# sourceMappingURL=main.js.map