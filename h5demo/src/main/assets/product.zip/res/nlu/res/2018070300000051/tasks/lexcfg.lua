local name = "nlucore";
local lexdb = {};

lexdb.use_trie = 1;
lexdb.data = {};
lexdb.pwd = "${pwd}";
lexdb.ext_path = lexdb.pwd .. "/../vocabs";

lexdb.data["sys.技能操作词"] = lexdb.pwd .. "/../vocabs/sys.技能操作词.bin";
lexdb.data["playstate"] = lexdb.pwd .. "/../vocabs/playstate.bin";
lexdb.data["sys.技能调用名"] = lexdb.pwd .. "/../vocabs/sys.技能调用名.bin";
lexdb.data["localsong"] = lexdb.pwd .. "/../vocabs/localsong.bin";
lexdb.data["祷告"] = lexdb.pwd .. "/../vocabs/祷告.bin";
lexdb.data["praysong"] = lexdb.pwd .. "/../vocabs/praysong.bin";
return lexdb;
