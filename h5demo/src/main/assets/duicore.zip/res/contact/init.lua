-------------------------------------------------------------------------------
-- Copyright (C), AISpeech Tech. Co., Ltd.
--
-- FileName    : contact.lua
-- Author      : jinrui.gan
-- Date        : 2017-06-22
-- Description : contact parse
--------------------------------------------------------------------------------
-- Record      :
--------------------------------------------------------------------------------
local aiconf = require('aiconf')
local ailog  = require('ailog')
local sqlite = require('luasql.sqlite3')
require('string.split')

local TAG = 'AI-contact'

local contact = {}

function contact.new()
    local cfg = aiconf.getconfig('contact')
    contact.operators = cfg.operator

    local dbpath = aiconf.respath .. 'contact/location.sqlite'
    contact.locdb = {}
    contact.locdb.env = sqlite.sqlite3()
    contact.locdb.conn = contact.locdb.env:connect(dbpath)

    return contact
end

function contact.release()
	contact.locdb.env:close()
    contact.locdb.conn:close()
end

function contact.getoperator(num)
	if not contact.operators then return end

	local sub = string.sub(num, 1, 3)
	return contact.operators[sub]
end

function contact.getlocation(num)
    local sub = string.sub(num, 1, 7)
    if not sub or #sub~=7 then return end

    local sql = string.format('SELECT area FROM phone_location WHERE _id=%s', sub)
    local res, msg = contact.locdb.conn:execute(sql)
    if msg then ailog.e(TAG, 'sql err:', sql, msg) return end

    local area = res:fetch()
    res:close()

    return area
end

function contact.getvalidname(s)
    local ss = {}
    for k = 1, #s do
        local c = string.byte(s,k)
        if not c then break end
        if (c >= 48 and c <= 57) or (c >= 65 and c <= 90) or (c >= 97 and c <= 122) then
            table.insert(ss, string.char(c))
        elseif c >= 228 and c <= 233 then
            local c1 = string.byte(s,k+1)
            local c2 = string.byte(s,k+2)
            if c1 and c2 then
                local a1,a2,a3,a4 = 128,191,128,191
                if c == 228 then a1 = 184
                elseif c == 233 then a2,a4 = 190,c1 ~= 190 and 191 or 165
                end
                if c1 >= a1 and c1 <= a2 and c2 >= a3 and c2 <= a4 then
                    k = k + 2
                    table.insert(ss, string.char(c,c1,c2))
                end
            end
        end
    end
    return table.concat(ss)
end

function contact.getsubnames(name)
    local tab = {}
    for uchar in string.gmatch(name, "[%z\1-\127\194-\244][\128-\191]*") do
        table.insert(tab, uchar)
    end

    local names = {}
    local tmp = ''
    local index = 1
    for i=1,#tab do
        if #tab[i] == 1 then -- match letter
            print(tab[i], #tab[i])
            for j=index+1,#tab do
                if #tab[j] == 3 and (index + 1 < j -1) then
                    tmp = table.concat(tab, '', index + 1, j - 1)
                    table.insert(names, tmp)
                    index = j
                    break
                end
            end
        else
            for j=i+1,#tab do
                if #tab[j] == 1 then break end
                if j - i <= 3 then
                    tmp = table.concat(tab, '', i, j)
                    table.insert(names, tmp)
                end
            end
        end
    end
    table.insert(names, name)
    return names
end

function contact.transnum(num)
    local tbl = { '零', '一', '二', '三', '四', '五', '六', '七', '八', '九' }
    local ret = {}
    for i=1,#num do
        table.insert(ret, tbl[tonumber(string.sub(num, i, i)) + 1 ])
    end
    return table.concat(ret, '')
end

function contact.transhz(num)
    local tbl = {
        ['零'] = '0',
        ['幺'] = '1',
        ['一'] = '1',
        ['二'] = '2',
        ['三'] = '3',
        ['四'] = '4',
        ['五'] = '5',
        ['六'] = '6',
        ['七'] = '7',
        ['八'] = '8',
        ['九'] = '9'
    }
    local ret = {}
    for i=1,#num,3 do
        table.insert(ret, tbl[string.sub(num, i, i + 2)])
    end
    return table.concat(ret, '')
end

function contact.getsubnums(num)
    local tab = {}
    for uchar in string.gfind(num, "[%d]") do
        table.insert(tab, uchar)
    end

    local nums = {}
    local tmp = ''
    for i=1,#tab do
        for j=i+1,#tab do
            if j - i <= 3 then
                tmp = table.concat(tab, '', i, j)
                table.insert(nums, tmp)
            end
        end
    end
    table.insert(nums, num)
    return nums
end

return contact