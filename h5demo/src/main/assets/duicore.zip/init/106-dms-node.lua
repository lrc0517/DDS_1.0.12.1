require('luabin')
local lubs = {
	playerconf.DATA_HOME .. '/core.lub',
	playerconf.DUICORE_HOME .. '/hybrid.lub',
	playerconf.DUICORE_HOME .. '/res/cdm/cdm.lub',
	playerconf.DUICORE_HOME .. '/res/nlu/semantic.lub'
}
luabin.path = table.concat(lubs, ';')
package.path = package.path ..';'.. playerconf.DUICORE_HOME .. '/res/nlu/semantic/?.lua;'
package.path = package.path ..';'.. playerconf.DATA_HOME .. '/lualib/external/?/init.lua;'
package.path = package.path ..';'.. playerconf.DUICORE_HOME .. '/res/?/init.lua;'

cdm_conf = {
    hz2py_db = playerconf.DUICORE_HOME .. '/res/cdm/hz2py.db'
}

local dmsnode = require 'player.node.dms'
dmsnode:run()
