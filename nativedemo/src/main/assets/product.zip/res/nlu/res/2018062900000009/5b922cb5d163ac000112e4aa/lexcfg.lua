local name = "nlucore";
local lexdb = {};

lexdb.use_trie = 1;
lexdb.data = {};
lexdb.pwd = "${pwd}";
lexdb.ext_path = lexdb.pwd .. "/../vocabs";

lexdb.data["rest"] = lexdb.pwd .. "/../vocabs/rest.bin";
return lexdb;
