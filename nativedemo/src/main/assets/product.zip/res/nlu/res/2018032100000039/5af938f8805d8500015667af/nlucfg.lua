local name = "nlucore";

local nludata={};

nludata.sys = {};
nludata.sys.res  = "5af938f8805d8500015667af";
nludata.sys.pwd = "${pwd}";
nludata.sys.use_slot_index = true;
nludata.sys.scpkernal_version = "0.0.8";

nludata.domain = {};
nludata.domain.default_domain = "@";
nludata.domain.use_force_domain=1;
nludata.domain.force_domain="桌面";
nludata.domain.fields = {};
nludata.domain.fields.num = 1;
nludata.domain.fields.set={};

nludata.domain.fields.set["桌面"]={ name="桌面", fn="${pwd}/lex/5af938f8805d8500015667af.lex.bin"};

nludata.db = {};
nludata.db.lex = {};
nludata.db.lex.fn = "${pwd}/lexcfg.lua";

nludata.lmlex = {};

nludata.processor = {};
nludata.processor.pre = {};
nludata.processor.pre.filter={"~","。","?","？","！","!",":","：","…","～","﹏","\"","\'","`","”","“","{","}","·","•","°","\t","\n",";","、","/",",","，",",","^"};

nludata.processor.post = {};
nludata.processor.post.cfg = {
	post_func   = "${pwd}/lua/postfunc.lua",
	reform_func = "${pwd}/lua/reformcb.lua"
}

nludata.pinyin = {};
nludata.pinyin.cfg = {
	bin_fn   = "${pwd}/../sempost/pinyin/pinyin_seg_sdx.bin",
	wrd_fn = "${pwd}/../sempost/pinyin/pinyin_seg_69k.bin"
}

return nludata;
